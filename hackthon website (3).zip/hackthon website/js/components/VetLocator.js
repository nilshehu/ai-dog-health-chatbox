class VetLocator extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        this.clinics = [];
        this.userLocation = null;
        this.map = null;
        this.markers = [];
    }

    async connectedCallback() {
        await this.loadMapScript();
        this.render();
        this.setupEventListeners();
        await this.getUserLocation();
    }

    async loadMapScript() {
        return new Promise((resolve, reject) => {
            if (window.L) {
                resolve();
                return;
            }

            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
            document.head.appendChild(link);

            const script = document.createElement('script');
            script.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';
            script.onload = resolve;
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    async getUserLocation() {
        try {
            const position = await new Promise((resolve, reject) => {
                navigator.geolocation.getCurrentPosition(resolve, reject);
            });

            this.userLocation = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };

            await this.initMap();
            await this.searchNearbyClinics();
        } catch (error) {
            console.error('Error getting user location:', error);
            this.showError('Unable to get your location. Please enter your address manually.');
        }
    }

    async initMap() {
        if (!this.userLocation) return;

        const mapContainer = this.shadowRoot.querySelector('#map');
        if (!mapContainer) return;

        this.map = L.map(mapContainer).setView([this.userLocation.lat, this.userLocation.lng], 13);
        
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '© OpenStreetMap contributors'
        }).addTo(this.map);

        // Add user location marker
        L.marker([this.userLocation.lat, this.userLocation.lng], {
            icon: L.divIcon({
                className: 'user-location-marker',
                html: '<div class="pulse"></div>'
            })
        }).addTo(this.map)
          .bindPopup('Your Location')
          .openPopup();
    }

    async searchNearbyClinics() {
        if (!this.userLocation) return;

        try {
            const response = await fetch(`https://overpass-api.de/api/interpreter`, {
                method: 'POST',
                body: `
                    [out:json];
                    (
                        node["amenity"="veterinary"](around:5000,${this.userLocation.lat},${this.userLocation.lng});
                        way["amenity"="veterinary"](around:5000,${this.userLocation.lat},${this.userLocation.lng});
                        relation["amenity"="veterinary"](around:5000,${this.userLocation.lat},${this.userLocation.lng});
                    );
                    out body;
                    >;
                    out skel qt;
                `
            });

            const data = await response.json();
            this.clinics = data.elements.filter(e => e.type === 'node').map(clinic => ({
                id: clinic.id,
                name: clinic.tags.name || 'Unknown Veterinary Clinic',
                lat: clinic.lat,
                lng: clinic.lon,
                address: clinic.tags.address || 'Address not available',
                phone: clinic.tags.phone || 'Phone not available',
                website: clinic.tags.website || null,
                openingHours: clinic.tags.opening_hours || 'Hours not available',
                distance: this.calculateDistance(
                    this.userLocation.lat,
                    this.userLocation.lng,
                    clinic.lat,
                    clinic.lon
                )
            }));

            this.addClinicMarkers();
            this.updateClinicsList();
        } catch (error) {
            console.error('Error fetching nearby clinics:', error);
            this.showError('Failed to fetch nearby veterinary clinics');
        }
    }

    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371; // Earth's radius in km
        const dLat = this.deg2rad(lat2 - lat1);
        const dLon = this.deg2rad(lon2 - lon1);
        const a = 
            Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * 
            Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return (R * c).toFixed(1);
    }

    deg2rad(deg) {
        return deg * (Math.PI/180);
    }

    addClinicMarkers() {
        // Clear existing markers
        this.markers.forEach(marker => marker.remove());
        this.markers = [];

        this.clinics.forEach(clinic => {
            const marker = L.marker([clinic.lat, clinic.lng], {
                icon: L.divIcon({
                    className: 'clinic-marker',
                    html: '<i class="fas fa-clinic-medical"></i>'
                })
            });

            marker.bindPopup(`
                <div class="clinic-popup">
                    <h3>${clinic.name}</h3>
                    <p><i class="fas fa-map-marker-alt"></i> ${clinic.address}</p>
                    <p><i class="fas fa-phone"></i> ${clinic.phone}</p>
                    ${clinic.website ? `<p><i class="fas fa-globe"></i> <a href="${clinic.website}" target="_blank">Website</a></p>` : ''}
                    <p><i class="fas fa-clock"></i> ${clinic.openingHours}</p>
                    <p><i class="fas fa-route"></i> ${clinic.distance} km away</p>
                    <button onclick="window.open('https://www.google.com/maps/dir/?api=1&destination=${clinic.lat},${clinic.lng}')">
                        Get Directions
                    </button>
                </div>
            `);

            marker.addTo(this.map);
            this.markers.push(marker);
        });
    }

    updateClinicsList() {
        const listContainer = this.shadowRoot.querySelector('#clinicsList');
        if (!listContainer) return;

        listContainer.innerHTML = this.clinics
            .sort((a, b) => a.distance - b.distance)
            .map(clinic => `
                <div class="clinic-card" data-id="${clinic.id}">
                    <h3>${clinic.name}</h3>
                    <p><i class="fas fa-map-marker-alt"></i> ${clinic.address}</p>
                    <p><i class="fas fa-route"></i> ${clinic.distance} km away</p>
                    <p><i class="fas fa-phone"></i> ${clinic.phone}</p>
                    <p><i class="fas fa-clock"></i> ${clinic.openingHours}</p>
                    ${clinic.website ? 
                        `<p><i class="fas fa-globe"></i> <a href="${clinic.website}" target="_blank">Visit Website</a></p>` 
                        : ''
                    }
                    <button class="directions-btn" onclick="window.open('https://www.google.com/maps/dir/?api=1&destination=${clinic.lat},${clinic.lng}')">
                        Get Directions
                    </button>
                </div>
            `).join('');
    }

    setupEventListeners() {
        const searchInput = this.shadowRoot.querySelector('#searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', () => this.filterClinics(searchInput.value));
        }

        const clinicsList = this.shadowRoot.querySelector('#clinicsList');
        if (clinicsList) {
            clinicsList.addEventListener('click', (e) => {
                const card = e.target.closest('.clinic-card');
                if (card) {
                    const clinicId = card.dataset.id;
                    const clinic = this.clinics.find(c => c.id === parseInt(clinicId));
                    if (clinic) {
                        this.map.setView([clinic.lat, clinic.lng], 15);
                        const marker = this.markers.find(m => 
                            m.getLatLng().lat === clinic.lat && 
                            m.getLatLng().lng === clinic.lng
                        );
                        if (marker) marker.openPopup();
                    }
                }
            });
        }
    }

    filterClinics(searchTerm) {
        const term = searchTerm.toLowerCase();
        const filteredClinics = this.clinics.filter(clinic => 
            clinic.name.toLowerCase().includes(term) ||
            clinic.address.toLowerCase().includes(term)
        );

        // Update markers visibility
        this.markers.forEach(marker => {
            const clinic = this.clinics.find(c => 
                c.lat === marker.getLatLng().lat && 
                c.lng === marker.getLatLng().lng
            );
            
            if (filteredClinics.includes(clinic)) {
                marker.addTo(this.map);
            } else {
                marker.remove();
            }
        });

        // Update list
        const listContainer = this.shadowRoot.querySelector('#clinicsList');
        if (listContainer) {
            listContainer.innerHTML = filteredClinics
                .sort((a, b) => a.distance - b.distance)
                .map(clinic => `
                    <div class="clinic-card" data-id="${clinic.id}">
                        <h3>${clinic.name}</h3>
                        <p><i class="fas fa-map-marker-alt"></i> ${clinic.address}</p>
                        <p><i class="fas fa-route"></i> ${clinic.distance} km away</p>
                        <p><i class="fas fa-phone"></i> ${clinic.phone}</p>
                        <p><i class="fas fa-clock"></i> ${clinic.openingHours}</p>
                        ${clinic.website ? 
                            `<p><i class="fas fa-globe"></i> <a href="${clinic.website}" target="_blank">Visit Website</a></p>` 
                            : ''
                        }
                        <button class="directions-btn" onclick="window.open('https://www.google.com/maps/dir/?api=1&destination=${clinic.lat},${clinic.lng}')">
                            Get Directions
                        </button>
                    </div>
                `).join('');
        }
    }

    showError(message) {
        const toast = document.createElement('div');
        toast.className = 'toast error';
        toast.textContent = message;
        this.shadowRoot.appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    }

    render() {
        const styles = `
            :host {
                display: block;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                --primary-color: #4CAF50;
                --error-color: #f44336;
                --border-radius: 8px;
                --shadow: 0 2px 4px rgba(0,0,0,0.1);
            }

            .container {
                display: grid;
                grid-template-columns: 1fr 2fr;
                gap: 2rem;
                padding: 1rem;
                height: 80vh;
            }

            .sidebar {
                background: white;
                border-radius: var(--border-radius);
                box-shadow: var(--shadow);
                overflow: hidden;
                display: flex;
                flex-direction: column;
            }

            .search-container {
                padding: 1rem;
                border-bottom: 1px solid #eee;
            }

            #searchInput {
                width: 100%;
                padding: 0.5rem;
                border: 1px solid #ddd;
                border-radius: var(--border-radius);
                font-size: 1rem;
            }

            #clinicsList {
                flex: 1;
                overflow-y: auto;
                padding: 1rem;
            }

            .clinic-card {
                background: #f9f9f9;
                border-radius: var(--border-radius);
                padding: 1rem;
                margin-bottom: 1rem;
                cursor: pointer;
                transition: transform 0.2s;
            }

            .clinic-card:hover {
                transform: translateY(-2px);
            }

            .clinic-card h3 {
                margin: 0 0 0.5rem 0;
                color: var(--primary-color);
            }

            .clinic-card p {
                margin: 0.25rem 0;
                color: #666;
            }

            .clinic-card i {
                width: 20px;
                color: var(--primary-color);
            }

            .directions-btn {
                background: var(--primary-color);
                color: white;
                border: none;
                padding: 0.5rem 1rem;
                border-radius: var(--border-radius);
                margin-top: 0.5rem;
                cursor: pointer;
                transition: background 0.3s;
            }

            .directions-btn:hover {
                background: #45a049;
            }

            #map {
                height: 100%;
                border-radius: var(--border-radius);
                box-shadow: var(--shadow);
            }

            .user-location-marker {
                background: none;
                border: none;
            }

            .pulse {
                width: 20px;
                height: 20px;
                background: var(--primary-color);
                border-radius: 50%;
                position: relative;
            }

            .pulse::after {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                border-radius: 50%;
                border: 2px solid var(--primary-color);
                animation: pulse 2s infinite;
            }

            @keyframes pulse {
                0% {
                    transform: scale(1);
                    opacity: 1;
                }
                100% {
                    transform: scale(3);
                    opacity: 0;
                }
            }

            .clinic-marker {
                color: var(--primary-color);
                font-size: 24px;
                text-align: center;
                line-height: 24px;
            }

            .clinic-popup {
                padding: 0.5rem;
            }

            .clinic-popup h3 {
                margin: 0 0 0.5rem 0;
                color: var(--primary-color);
            }

            .clinic-popup p {
                margin: 0.25rem 0;
            }

            .toast {
                position: fixed;
                bottom: 2rem;
                right: 2rem;
                padding: 1rem 2rem;
                border-radius: var(--border-radius);
                color: white;
                z-index: 1000;
            }

            .toast.error {
                background: var(--error-color);
            }

            @media (max-width: 768px) {
                .container {
                    grid-template-columns: 1fr;
                    height: auto;
                }

                #map {
                    height: 400px;
                }
            }
        `;

        const content = `
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
            <div class="container">
                <div class="sidebar">
                    <div class="search-container">
                        <input type="text" id="searchInput" placeholder="Search veterinary clinics...">
                    </div>
                    <div id="clinicsList">
                        <p>Loading nearby veterinary clinics...</p>
                    </div>
                </div>
                <div id="map"></div>
            </div>
        `;

        this.shadowRoot.innerHTML = `
            <style>${styles}</style>
            ${content}
        `;
    }
}

customElements.define('vet-locator', VetLocator); 