class PetProfile extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
        this.pet = null;
        this.healthRecords = [];
    }

    static get observedAttributes() {
        return ['pet-id'];
    }

    async connectedCallback() {
        await this.loadPetData();
        this.render();
        this.setupEventListeners();
    }

    async loadPetData() {
        try {
            const petId = this.getAttribute('pet-id');
            const response = await fetch(`/api/pets/${petId}`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            
            if (!response.ok) throw new Error('Failed to load pet data');
            
            this.pet = await response.json();
            this.healthRecords = await this.loadHealthRecords();
            this.render();
        } catch (error) {
            console.error('Error loading pet data:', error);
            this.showError('Failed to load pet data');
        }
    }

    async loadHealthRecords() {
        try {
            const response = await fetch(`/api/health-records/${this.pet._id}`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });
            
            if (!response.ok) throw new Error('Failed to load health records');
            
            return await response.json();
        } catch (error) {
            console.error('Error loading health records:', error);
            return [];
        }
    }

    setupEventListeners() {
        const addRecordBtn = this.shadowRoot.querySelector('#addRecordBtn');
        const uploadPhotoBtn = this.shadowRoot.querySelector('#uploadPhotoBtn');
        
        addRecordBtn?.addEventListener('click', () => this.showAddRecordModal());
        uploadPhotoBtn?.addEventListener('click', () => this.showPhotoUploadModal());
        
        // Health record form submission
        const recordForm = this.shadowRoot.querySelector('#healthRecordForm');
        recordForm?.addEventListener('submit', (e) => this.handleRecordSubmit(e));
    }

    async handleRecordSubmit(event) {
        event.preventDefault();
        const form = event.target;
        
        try {
            const formData = new FormData(form);
            const recordData = {
                type: formData.get('type'),
                date: formData.get('date'),
                description: formData.get('description'),
                vetName: formData.get('vetName'),
                medications: formData.get('medications'),
                nextCheckup: formData.get('nextCheckup')
            };

            const response = await fetch(`/api/health-records/${this.pet._id}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify(recordData)
            });

            if (!response.ok) throw new Error('Failed to save health record');

            await this.loadHealthRecords();
            this.closeModal();
            this.showSuccess('Health record added successfully');
        } catch (error) {
            console.error('Error saving health record:', error);
            this.showError('Failed to save health record');
        }
    }

    async uploadPhoto(file) {
        try {
            const formData = new FormData();
            formData.append('image', file);

            const response = await fetch('/api/upload', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: formData
            });

            if (!response.ok) throw new Error('Upload failed');

            const result = await response.json();
            
            // Update pet photo in database
            await fetch(`/api/pets/${this.pet._id}/photo`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify({ photoUrl: result.processedUrl })
            });

            // Update local pet data
            this.pet.photo = result.processedUrl;
            this.render();
            this.showSuccess('Photo updated successfully');
        } catch (error) {
            console.error('Photo upload error:', error);
            this.showError('Failed to upload photo');
        }
    }

    showAddRecordModal() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <h2>Add Health Record</h2>
                <form id="healthRecordForm">
                    <div class="form-group">
                        <label for="type">Record Type</label>
                        <select name="type" required>
                            <option value="checkup">Regular Checkup</option>
                            <option value="vaccination">Vaccination</option>
                            <option value="illness">Illness</option>
                            <option value="injury">Injury</option>
                            <option value="surgery">Surgery</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="date">Date</label>
                        <input type="date" name="date" required>
                    </div>
                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea name="description" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="vetName">Veterinarian</label>
                        <input type="text" name="vetName">
                    </div>
                    <div class="form-group">
                        <label for="medications">Medications</label>
                        <input type="text" name="medications">
                    </div>
                    <div class="form-group">
                        <label for="nextCheckup">Next Checkup Date</label>
                        <input type="date" name="nextCheckup">
                    </div>
                    <div class="form-actions">
                        <button type="submit">Save Record</button>
                        <button type="button" onclick="this.closeModal()">Cancel</button>
                    </div>
                </form>
            </div>
        `;
        this.shadowRoot.appendChild(modal);
    }

    showPhotoUploadModal() {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <h2>Update Pet Photo</h2>
                <div class="upload-area" id="uploadArea">
                    <input type="file" id="photoInput" accept="image/*" style="display: none;">
                    <div class="drop-zone">
                        <i class="fas fa-cloud-upload-alt"></i>
                        <p>Drag & drop your photo here or click to select</p>
                    </div>
                    <img id="preview" style="display: none; max-width: 100%; margin-top: 1rem;">
                </div>
                <div class="form-actions">
                    <button id="uploadBtn" disabled>Upload Photo</button>
                    <button type="button" onclick="this.closeModal()">Cancel</button>
                </div>
            </div>
        `;

        const uploadArea = modal.querySelector('#uploadArea');
        const photoInput = modal.querySelector('#photoInput');
        const preview = modal.querySelector('#preview');
        const uploadBtn = modal.querySelector('#uploadBtn');

        // Handle drag and drop
        uploadArea.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });

        uploadArea.addEventListener('dragleave', () => {
            uploadArea.classList.remove('dragover');
        });

        uploadArea.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            const file = e.dataTransfer.files[0];
            if (file && file.type.startsWith('image/')) {
                handleFile(file);
            }
        });

        // Handle click to select
        uploadArea.addEventListener('click', () => {
            photoInput.click();
        });

        photoInput.addEventListener('change', () => {
            const file = photoInput.files[0];
            if (file) {
                handleFile(file);
            }
        });

        const handleFile = (file) => {
            // Show preview
            const reader = new FileReader();
            reader.onload = (e) => {
                preview.src = e.target.result;
                preview.style.display = 'block';
                uploadBtn.disabled = false;
            };
            reader.readAsDataURL(file);

            // Store file for upload
            uploadArea.dataset.file = file;
        };

        uploadBtn.addEventListener('click', async () => {
            const file = uploadArea.dataset.file;
            if (file) {
                await this.uploadPhoto(file);
                this.closeModal();
            }
        });

        this.shadowRoot.appendChild(modal);
    }

    closeModal() {
        const modal = this.shadowRoot.querySelector('.modal');
        modal?.remove();
    }

    showSuccess(message) {
        const toast = document.createElement('div');
        toast.className = 'toast success';
        toast.textContent = message;
        this.shadowRoot.appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    }

    showError(message) {
        const toast = document.createElement('div');
        toast.className = 'toast error';
        toast.textContent = message;
        this.shadowRoot.appendChild(toast);
        setTimeout(() => toast.remove(), 3000);
    }

    render() {
        const styles = `
            :host {
                display: block;
                font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                --primary-color: #4CAF50;
                --error-color: #f44336;
                --success-color: #4CAF50;
                --border-radius: 8px;
                --shadow: 0 2px 4px rgba(0,0,0,0.1);
            }

            .pet-profile {
                background: white;
                border-radius: var(--border-radius);
                box-shadow: var(--shadow);
                padding: 2rem;
                margin: 1rem;
            }

            .pet-header {
                display: flex;
                align-items: center;
                gap: 2rem;
                margin-bottom: 2rem;
            }

            .pet-photo {
                width: 150px;
                height: 150px;
                border-radius: 50%;
                object-fit: cover;
                border: 3px solid var(--primary-color);
            }

            .pet-info {
                flex: 1;
            }

            .pet-name {
                font-size: 2rem;
                margin: 0;
                color: var(--primary-color);
            }

            .pet-details {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                gap: 1rem;
                margin-top: 1rem;
            }

            .detail-item {
                background: #f5f5f5;
                padding: 1rem;
                border-radius: var(--border-radius);
            }

            .health-records {
                margin-top: 2rem;
            }

            .record-item {
                background: #f9f9f9;
                border-radius: var(--border-radius);
                padding: 1rem;
                margin: 1rem 0;
                border-left: 4px solid var(--primary-color);
            }

            .button {
                background: var(--primary-color);
                color: white;
                border: none;
                padding: 0.5rem 1rem;
                border-radius: var(--border-radius);
                cursor: pointer;
                transition: background 0.3s;
            }

            .button:hover {
                background: #45a049;
            }

            .modal {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.5);
                display: flex;
                justify-content: center;
                align-items: center;
            }

            .modal-content {
                background: white;
                padding: 2rem;
                border-radius: var(--border-radius);
                max-width: 500px;
                width: 90%;
            }

            .form-group {
                margin-bottom: 1rem;
            }

            .form-group label {
                display: block;
                margin-bottom: 0.5rem;
            }

            .form-group input,
            .form-group select,
            .form-group textarea {
                width: 100%;
                padding: 0.5rem;
                border: 1px solid #ddd;
                border-radius: 4px;
            }

            .form-actions {
                display: flex;
                gap: 1rem;
                justify-content: flex-end;
                margin-top: 1rem;
            }

            .toast {
                position: fixed;
                bottom: 2rem;
                right: 2rem;
                padding: 1rem 2rem;
                border-radius: var(--border-radius);
                color: white;
                animation: slideIn 0.3s ease-out;
            }

            .toast.success {
                background: var(--success-color);
            }

            .toast.error {
                background: var(--error-color);
            }

            @keyframes slideIn {
                from {
                    transform: translateX(100%);
                    opacity: 0;
                }
                to {
                    transform: translateX(0);
                    opacity: 1;
                }
            }

            .upload-area {
                border: 2px dashed #ccc;
                border-radius: var(--border-radius);
                padding: 2rem;
                text-align: center;
                cursor: pointer;
                transition: all 0.3s;
            }

            .upload-area.dragover {
                border-color: var(--primary-color);
                background: rgba(76, 175, 80, 0.1);
            }

            .drop-zone {
                display: flex;
                flex-direction: column;
                align-items: center;
                gap: 1rem;
            }

            .drop-zone i {
                font-size: 3rem;
                color: var(--primary-color);
            }

            #uploadBtn:disabled {
                background: #ccc;
                cursor: not-allowed;
            }
        `;

        const content = `
            <div class="pet-profile">
                <div class="pet-header">
                    <img src="${this.pet?.photo || 'default-pet.jpg'}" alt="${this.pet?.name}" class="pet-photo">
                    <div class="pet-info">
                        <h1 class="pet-name">${this.pet?.name || 'Loading...'}</h1>
                        <div class="pet-details">
                            <div class="detail-item">
                                <strong>Breed:</strong> ${this.pet?.breed || 'N/A'}
                            </div>
                            <div class="detail-item">
                                <strong>Age:</strong> ${this.pet?.age || 'N/A'} years
                            </div>
                            <div class="detail-item">
                                <strong>Weight:</strong> ${this.pet?.weight || 'N/A'} kg
                            </div>
                        </div>
                        <div class="actions">
                            <button id="addRecordBtn" class="button">Add Health Record</button>
                            <button id="uploadPhotoBtn" class="button">Update Photo</button>
                        </div>
                    </div>
                </div>

                <div class="health-records">
                    <h2>Health Records</h2>
                    ${this.healthRecords.length ? this.healthRecords.map(record => `
                        <div class="record-item">
                            <h3>${record.type}</h3>
                            <p><strong>Date:</strong> ${new Date(record.date).toLocaleDateString()}</p>
                            <p><strong>Description:</strong> ${record.description}</p>
                            ${record.vetName ? `<p><strong>Veterinarian:</strong> ${record.vetName}</p>` : ''}
                            ${record.medications ? `<p><strong>Medications:</strong> ${record.medications}</p>` : ''}
                            ${record.nextCheckup ? `<p><strong>Next Checkup:</strong> ${new Date(record.nextCheckup).toLocaleDateString()}</p>` : ''}
                        </div>
                    `).join('') : '<p>No health records found.</p>'}
                </div>
            </div>
        `;

        this.shadowRoot.innerHTML = `
            <style>${styles}</style>
            ${content}
        `;
    }
}

customElements.define('pet-profile', PetProfile); 