import './components/PetProfile.js';
import './components/VetLocator.js';

// Initialize Socket.IO for real-time updates
const socket = io();

// Handle real-time vet availability updates
socket.on('vet-status-update', (data) => {
    const vetLocator = document.querySelector('vet-locator');
    if (vetLocator) {
        vetLocator.updateClinicStatus(data);
    }
});

// Handle emergency alerts
socket.on('emergency-alert', (data) => {
    showEmergencyAlert(data);
});

// Initialize service worker for offline support
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js')
        .then(registration => {
            console.log('ServiceWorker registration successful');
        })
        .catch(err => {
            console.error('ServiceWorker registration failed:', err);
        });
}

// Theme handling
const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
function updateTheme(e) {
    document.documentElement.classList.toggle('dark', e.matches);
}
prefersDark.addListener(updateTheme);
updateTheme(prefersDark);

// Show emergency alert
function showEmergencyAlert(data) {
    const alert = document.createElement('div');
    alert.className = 'emergency-alert';
    alert.innerHTML = `
        <h3>Emergency Alert</h3>
        <p>${data.message}</p>
        <button onclick="this.parentElement.remove()">Dismiss</button>
    `;
    document.body.appendChild(alert);
}

// Export utility functions for components
export const utils = {
    formatDate: (date) => new Date(date).toLocaleDateString(),
    calculateAge: (birthDate) => {
        const diff = Date.now() - new Date(birthDate).getTime();
        return Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25));
    },
    formatPhoneNumber: (phone) => {
        const cleaned = ('' + phone).replace(/\D/g, '');
        const match = cleaned.match(/^(\d{3})(\d{3})(\d{4})$/);
        if (match) {
            return '(' + match[1] + ') ' + match[2] + '-' + match[3];
        }
        return phone;
    }
}; 