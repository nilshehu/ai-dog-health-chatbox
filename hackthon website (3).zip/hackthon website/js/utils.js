// Theme handling
export const ThemeUtils = {
    THEME_KEY: 'theme',
    DARK: 'dark',
    LIGHT: 'light',

    getCurrentTheme() {
        return localStorage.getItem(this.THEME_KEY) || this.LIGHT;
    },

    setTheme(theme) {
        const html = document.documentElement;
        const body = document.body;
        const themeIcon = document.getElementById('themeIcon');
        
        localStorage.setItem(this.THEME_KEY, theme);
        
        if (theme === this.DARK) {
            html.classList.add(this.DARK);
            body.classList.add(this.DARK);
            themeIcon.classList.remove('fa-moon');
            themeIcon.classList.add('fa-sun');
        } else {
            html.classList.remove(this.DARK);
            body.classList.remove(this.DARK);
            themeIcon.classList.remove('fa-sun');
            themeIcon.classList.add('fa-moon');
        }
    },

    toggleTheme() {
        const currentTheme = this.getCurrentTheme();
        const newTheme = currentTheme === this.DARK ? this.LIGHT : this.DARK;
        this.setTheme(newTheme);
    }
};

// Form validation
export const ValidationUtils = {
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    },

    isValidPassword(password) {
        return password.length >= 8;
    },

    validateLoginForm(email, password) {
        const errors = {};
        
        if (!this.isValidEmail(email)) {
            errors.email = 'Please enter a valid email address';
        }
        
        if (!password) {
            errors.password = 'Password is required';
        }
        
        return errors;
    },

    validateRegistrationForm(name, email, password, confirmPassword) {
        const errors = {};
        
        if (!name || name.trim().length < 2) {
            errors.name = 'Name must be at least 2 characters long';
        }
        
        if (!this.isValidEmail(email)) {
            errors.email = 'Please enter a valid email address';
        }
        
        if (!this.isValidPassword(password)) {
            errors.password = 'Password must be at least 8 characters long';
        }
        
        if (password !== confirmPassword) {
            errors.confirmPassword = 'Passwords do not match';
        }
        
        return errors;
    }
};

// UI helpers
export const UIUtils = {
    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `fixed bottom-4 right-4 p-4 rounded-lg shadow-lg ${
            type === 'error' ? 'bg-red-500' : 
            type === 'success' ? 'bg-green-500' : 
            'bg-blue-500'
        } text-white`;
        toast.textContent = message;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.remove();
        }, 3000);
    },

    showLoadingSpinner(show = true) {
        let spinner = document.getElementById('loading-spinner');
        
        if (show) {
            if (!spinner) {
                spinner = document.createElement('div');
                spinner.id = 'loading-spinner';
                spinner.className = 'fixed top-0 left-0 w-full h-full flex items-center justify-center bg-black bg-opacity-50 z-50';
                spinner.innerHTML = `
                    <div class="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-white"></div>
                `;
                document.body.appendChild(spinner);
            }
        } else if (spinner) {
            spinner.remove();
        }
    }
};

// Emergency detection
export const EmergencyUtils = {
    EMERGENCY_KEYWORDS: [
        'emergency',
        'urgent',
        'bleeding',
        'poison',
        'accident',
        'dying',
        'vomiting',
        'unconscious',
        'seizure',
        'collapse'
    ],

    isEmergency(message) {
        return this.EMERGENCY_KEYWORDS.some(keyword => 
            message.toLowerCase().includes(keyword)
        );
    },

    handleEmergency() {
        UIUtils.showToast('⚠️ This sounds like an emergency! Redirecting to emergency contacts...', 'error');
        showVets();
    }
};

// Date formatting
export const DateUtils = {
    formatDate(date) {
        return new Intl.DateTimeFormat('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        }).format(date);
    },

    getTimeAgo(date) {
        const seconds = Math.floor((new Date() - date) / 1000);
        
        let interval = seconds / 31536000;
        if (interval > 1) return Math.floor(interval) + ' years ago';
        
        interval = seconds / 2592000;
        if (interval > 1) return Math.floor(interval) + ' months ago';
        
        interval = seconds / 86400;
        if (interval > 1) return Math.floor(interval) + ' days ago';
        
        interval = seconds / 3600;
        if (interval > 1) return Math.floor(interval) + ' hours ago';
        
        interval = seconds / 60;
        if (interval > 1) return Math.floor(interval) + ' minutes ago';
        
        return Math.floor(seconds) + ' seconds ago';
    }
}; 