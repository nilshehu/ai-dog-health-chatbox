import ApiService from './api.js';
import { UIUtils, EmergencyUtils } from './utils.js';

class ChatManager {
    constructor() {
        this.messageInput = document.getElementById('messageInput');
        this.messages = document.getElementById('messages');
        this.imageInput = document.getElementById('imageInput');
        this.imagePreview = document.getElementById('imagePreview');
        this.dropZone = document.getElementById('dropZone');
        
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Message input
        this.messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        // Image upload
        this.imageInput.addEventListener('change', (e) => this.handleImageUpload(e));
        
        // Drag and drop
        this.dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            this.dropZone.classList.add('border-blue-500');
        });

        this.dropZone.addEventListener('dragleave', (e) => {
            e.preventDefault();
            this.dropZone.classList.remove('border-blue-500');
        });

        this.dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            this.dropZone.classList.remove('border-blue-500');
            
            const file = e.dataTransfer.files[0];
            if (file && file.type.startsWith('image/')) {
                this.imageInput.files = e.dataTransfer.files;
                this.handleImageUpload({ target: { files: [file] } });
            } else {
                UIUtils.showToast('Please upload an image file', 'error');
            }
        });
    }

    async sendMessage() {
        const message = this.messageInput.value.trim();
        if (!message) return;

        try {
            // Add user message to chat
            this.addMessageToChat(message, true);
            this.messageInput.value = '';

            // Check for emergency
            if (EmergencyUtils.isEmergency(message)) {
                EmergencyUtils.handleEmergency();
                return;
            }

            // Show loading state
            const loadingId = this.showLoadingMessage();

            // Send message to API
            const response = await ApiService.sendMessage(message);

            // Remove loading message
            this.removeLoadingMessage(loadingId);

            // Add bot response
            if (response && response.reply) {
                this.addMessageToChat(response.reply, false);
            } else {
                throw new Error('Invalid response from server');
            }

        } catch (error) {
            console.error('Error sending message:', error);
            UIUtils.showToast('Failed to send message. Please try again.', 'error');
        }
    }

    addMessageToChat(message, isUser) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `flex items-start mb-4 ${isUser ? 'justify-end' : ''}`;
        
        messageDiv.innerHTML = `
            <div class="flex-shrink-0 ${isUser ? 'order-2 ml-3' : 'mr-3'}">
                <i class="fas ${isUser ? 'fa-user text-green-500' : 'fa-robot text-blue-500'} text-2xl"></i>
            </div>
            <div class="${isUser ? 'order-1' : ''} bg-${isUser ? 'green-100' : 'gray-100'} dark:bg-${isUser ? 'green-800' : 'gray-700'} rounded-lg p-3 theme-transition max-w-[80%]">
                <p class="dark:text-white whitespace-pre-wrap break-words">${this.formatMessage(message)}</p>
                <span class="text-xs text-gray-500 dark:text-gray-400 mt-1 block">${new Date().toLocaleTimeString()}</span>
            </div>
        `;
        
        this.messages.appendChild(messageDiv);
        this.messages.scrollTop = this.messages.scrollHeight;
    }

    formatMessage(message) {
        // Convert URLs to clickable links
        message = message.replace(
            /(https?:\/\/[^\s]+)/g,
            '<a href="$1" target="_blank" class="text-blue-500 hover:underline">$1</a>'
        );

        // Convert markdown-style links
        message = message.replace(
            /\[([^\]]+)\]\(([^)]+)\)/g,
            '<a href="$2" target="_blank" class="text-blue-500 hover:underline">$1</a>'
        );

        // Escape HTML but preserve the links we just created
        message = message
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/&lt;a href/g, '<a href')
            .replace(/&lt;\/a&gt;/g, '</a>');

        return message;
    }

    showLoadingMessage() {
        const loadingId = 'loading-' + Date.now();
        const loadingDiv = document.createElement('div');
        loadingDiv.id = loadingId;
        loadingDiv.className = 'flex items-start mb-4';
        loadingDiv.innerHTML = `
            <div class="flex-shrink-0 mr-3">
                <i class="fas fa-robot text-blue-500 text-2xl"></i>
            </div>
            <div class="bg-gray-100 dark:bg-gray-700 rounded-lg p-3 theme-transition">
                <p class="dark:text-white loading-dots">Thinking</p>
            </div>
        `;
        this.messages.appendChild(loadingDiv);
        this.messages.scrollTop = this.messages.scrollHeight;
        return loadingId;
    }

    removeLoadingMessage(loadingId) {
        const loadingDiv = document.getElementById(loadingId);
        if (loadingDiv) {
            loadingDiv.remove();
        }
    }

    async handleImageUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        if (!file.type.startsWith('image/')) {
            UIUtils.showToast('Please upload an image file', 'error');
            return;
        }

        try {
            UIUtils.showLoadingSpinner(true);

            const reader = new FileReader();
            reader.onload = async (e) => {
                // Show preview
                const previewImg = document.getElementById('previewImg');
                previewImg.src = e.target.result;
                this.imagePreview.classList.remove('hidden');

                try {
                    // Analyze image
                    const analysis = await this.analyzeImage(e.target.result);
                    this.addMessageToChat(analysis, false);
                } catch (error) {
                    console.error('Error analyzing image:', error);
                    UIUtils.showToast('Failed to analyze image. Please try again.', 'error');
                } finally {
                    UIUtils.showLoadingSpinner(false);
                }
            };
            reader.readAsDataURL(file);
        } catch (error) {
            console.error('Error handling image upload:', error);
            UIUtils.showToast('Failed to upload image. Please try again.', 'error');
            UIUtils.showLoadingSpinner(false);
        }
    }

    async analyzeImage(imageData) {
        try {
            const base64Response = await fetch(imageData);
            const blob = await base64Response.blob();

            const response = await fetch('https://api-inference.huggingface.co/models/microsoft/resnet-50', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${process.env.HUGGING_FACE_API_KEY}`
                },
                body: blob
            });

            if (!response.ok) {
                throw new Error('Failed to analyze image');
            }

            const result = await response.json();
            
            if (Array.isArray(result)) {
                let analysis = "Here's what I see in the image:\n\n";
                result.slice(0, 3).forEach((item, index) => {
                    const confidence = (item.score * 100).toFixed(1);
                    analysis += `${index + 1}. ${item.label} (${confidence}% confident)\n`;
                });
                analysis += "\nIf you're concerned about something specific in this image, please describe what you're seeing. Remember that while I can help identify visible symptoms, a veterinarian should always be consulted for proper diagnosis.";
                return analysis;
            } else {
                throw new Error('Invalid response format');
            }
        } catch (error) {
            throw new Error('Failed to analyze image: ' + error.message);
        }
    }

    removeImage() {
        this.imagePreview.classList.add('hidden');
        document.getElementById('previewImg').src = '';
        this.imageInput.value = '';
    }
}

// Initialize chat manager
const chatManager = new ChatManager();

// Export for use in other modules
export default chatManager; 