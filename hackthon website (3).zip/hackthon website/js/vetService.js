import ApiService from './api.js';
import { UIUtils } from './utils.js';

class VetService {
    constructor() {
        this.currentPosition = null;
        this.searchResults = [];
        this.statusDiv = document.getElementById('locationStatus');
        this.resultsDiv = document.getElementById('searchResults');
    }

    async getCurrentLocation() {
        this.updateStatus("Requesting location access...");

        if (!navigator.geolocation) {
            this.updateStatus("Geolocation is not supported by your browser");
            return;
        }

        try {
            const position = await new Promise((resolve, reject) => {
                navigator.geolocation.getCurrentPosition(resolve, reject);
            });

            this.currentPosition = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };

            this.updateStatus("Location found! Searching for nearby clinics...");
            await this.searchNearbyVets();
        } catch (error) {
            let errorMessage = "An unknown error occurred.";
            
            switch(error.code) {
                case error.PERMISSION_DENIED:
                    errorMessage = "Location access was denied. Please enter your location manually.";
                    break;
                case error.POSITION_UNAVAILABLE:
                    errorMessage = "Location information is unavailable. Please try again or enter manually.";
                    break;
                case error.TIMEOUT:
                    errorMessage = "Location request timed out. Please try again or enter manually.";
                    break;
            }
            
            this.updateStatus(errorMessage);
            UIUtils.showToast(errorMessage, 'error');
        }
    }

    async searchByLocation(locationQuery) {
        if (!locationQuery.trim()) {
            this.updateStatus("Please enter a location to search");
            return;
        }

        this.updateStatus("Searching for veterinary clinics...");

        try {
            // First, geocode the location query to get coordinates
            const geocodeUrl = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(locationQuery)}`;
            const response = await fetch(geocodeUrl);
            const data = await response.json();

            if (data && data.length > 0) {
                this.currentPosition = {
                    lat: parseFloat(data[0].lat),
                    lng: parseFloat(data[0].lon)
                };
                await this.searchNearbyVets();
            } else {
                throw new Error('Location not found');
            }
        } catch (error) {
            console.error('Error searching location:', error);
            this.updateStatus("Could not find the specified location. Please try again.");
            UIUtils.showToast('Location search failed. Please try again.', 'error');
        }
    }

    async searchNearbyVets() {
        if (!this.currentPosition) {
            this.updateStatus("No location available. Please try again.");
            return;
        }

        try {
            UIUtils.showLoadingSpinner(true);

            // Use Overpass API to find veterinary clinics
            const radius = 5000; // 5km radius
            const query = `
                [out:json][timeout:25];
                (
                    node["amenity"="veterinary"](around:${radius},${this.currentPosition.lat},${this.currentPosition.lng});
                    way["amenity"="veterinary"](around:${radius},${this.currentPosition.lat},${this.currentPosition.lng});
                    relation["amenity"="veterinary"](around:${radius},${this.currentPosition.lat},${this.currentPosition.lng});
                );
                out body;
                >;
                out skel qt;
            `;

            const response = await fetch('https://overpass-api.de/api/interpreter', {
                method: 'POST',
                body: query
            });

            if (!response.ok) {
                throw new Error('Failed to fetch veterinary clinics');
            }

            const data = await response.json();
            this.searchResults = this.processVetData(data);
            
            this.updateStatus(`Found ${this.searchResults.length} veterinary clinics in your area`);
            this.displayResults();
        } catch (error) {
            console.error('Error searching for vets:', error);
            this.updateStatus("Error finding veterinary clinics. Please try again.");
            UIUtils.showToast('Search failed. Please try again.', 'error');
        } finally {
            UIUtils.showLoadingSpinner(false);
        }
    }

    processVetData(data) {
        const results = [];
        
        if (data.elements) {
            data.elements.forEach(element => {
                if (element.tags && element.tags.amenity === 'veterinary') {
                    const clinic = {
                        id: element.id,
                        name: element.tags.name || 'Unnamed Veterinary Clinic',
                        address: element.tags['addr:street'] ? 
                            `${element.tags['addr:housenumber'] || ''} ${element.tags['addr:street']}` : 
                            'Address not available',
                        phone: element.tags.phone || element.tags['contact:phone'] || 'Phone not available',
                        emergency: element.tags['emergency'] === 'yes',
                        website: element.tags.website || element.tags['contact:website'],
                        opening_hours: element.tags.opening_hours || 'Hours not available',
                        distance: this.calculateDistance(
                            this.currentPosition.lat,
                            this.currentPosition.lng,
                            element.lat,
                            element.lon
                        )
                    };
                    results.push(clinic);
                }
            });
        }

        // Sort by distance
        return results.sort((a, b) => a.distance - b.distance);
    }

    calculateDistance(lat1, lon1, lat2, lon2) {
        const R = 6371; // Earth's radius in km
        const dLat = this.deg2rad(lat2 - lat1);
        const dLon = this.deg2rad(lon2 - lon1);
        const a = 
            Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(this.deg2rad(lat1)) * Math.cos(this.deg2rad(lat2)) * 
            Math.sin(dLon/2) * Math.sin(dLon/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        const distance = R * c;
        return distance;
    }

    deg2rad(deg) {
        return deg * (Math.PI/180);
    }

    displayResults() {
        if (!this.resultsDiv) return;

        this.resultsDiv.innerHTML = '';
        
        this.searchResults.forEach(clinic => {
            const clinicCard = document.createElement('div');
            clinicCard.className = `bg-white dark:bg-gray-800 rounded-lg shadow p-4 border-l-4 ${
                clinic.emergency ? 'border-red-500' : 'border-green-500'
            } transition-transform hover:-translate-y-1`;

            clinicCard.innerHTML = `
                <div class="flex justify-between items-start">
                    <div>
                        <h3 class="text-xl font-bold mb-2">${clinic.name}</h3>
                        <p class="text-gray-600 dark:text-gray-300 mb-2">📍 ${clinic.address}</p>
                        <p class="text-gray-600 dark:text-gray-300 mb-2">📞 ${clinic.phone}</p>
                        <p class="text-gray-600 dark:text-gray-300 mb-2">📏 ${clinic.distance.toFixed(1)} km</p>
                        ${clinic.opening_hours ? `<p class="text-gray-600 dark:text-gray-300 mb-2">🕒 ${clinic.opening_hours}</p>` : ''}
                    </div>
                    ${clinic.emergency ? '<span class="bg-red-100 text-red-800 text-sm px-2 py-1 rounded">24/7 Emergency</span>' : ''}
                </div>
                <div class="mt-4 flex gap-2">
                    <button onclick="vetService.callVet('${clinic.phone}')" 
                        class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors">
                        Call Now
                    </button>
                    <button onclick="vetService.getDirections('${encodeURIComponent(clinic.address)}')" 
                        class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition-colors">
                        Get Directions
                    </button>
                    ${clinic.website ? `
                        <a href="${clinic.website}" target="_blank" 
                            class="bg-purple-500 text-white px-4 py-2 rounded hover:bg-purple-600 transition-colors">
                            Website
                        </a>
                    ` : ''}
                </div>
            `;

            this.resultsDiv.appendChild(clinicCard);
        });

        if (this.searchResults.length === 0) {
            this.resultsDiv.innerHTML = `
                <div class="text-center p-4">
                    <p class="text-gray-600 dark:text-gray-300">No veterinary clinics found in your area.</p>
                    <p class="text-gray-600 dark:text-gray-300 mt-2">Try searching with a different location or expanding your search radius.</p>
                </div>
            `;
        }
    }

    updateStatus(message) {
        if (this.statusDiv) {
            this.statusDiv.textContent = message;
        }
    }

    callVet(number) {
        if (number && number !== 'Phone not available') {
            window.location.href = `tel:${number.replace(/[^\d+]/g, '')}`;
        } else {
            UIUtils.showToast('Phone number not available', 'error');
        }
    }

    getDirections(address) {
        if (address && address !== 'Address not available') {
            window.open(`https://www.google.com/maps/search/?api=1&query=${address}`, '_blank');
        } else {
            UIUtils.showToast('Address not available', 'error');
        }
    }
}

// Create and export instance
const vetService = new VetService();
export default vetService;

// Make it available globally for inline event handlers
window.vetService = vetService; 