// API endpoints
const API_ENDPOINTS = {
    CHAT: '/api/chat',
    LOGIN: '/api/auth/login',
    REGISTER: '/api/auth/register',
    VETS: '/api/vets'
};

// API error handler
function handleApiError(error) {
    console.error('API Error:', error);
    throw new Error(error.message || 'An unexpected error occurred');
}

// API service
const ApiService = {
    // Chat API
    async sendMessage(message) {
        try {
            const response = await fetch(API_ENDPOINTS.CHAT, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify({ message })
            });

            if (!response.ok) {
                throw new Error(`API error: ${response.status}`);
            }

            return await response.json();
        } catch (error) {
            handleApiError(error);
        }
    },

    // Auth APIs
    async login(credentials) {
        try {
            const response = await fetch(API_ENDPOINTS.LOGIN, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(credentials)
            });

            if (!response.ok) {
                throw new Error('Invalid credentials');
            }

            const data = await response.json();
            localStorage.setItem('token', data.token);
            return data;
        } catch (error) {
            handleApiError(error);
        }
    },

    async register(userData) {
        try {
            const response = await fetch(API_ENDPOINTS.REGISTER, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });

            if (!response.ok) {
                throw new Error('Registration failed');
            }

            const data = await response.json();
            localStorage.setItem('token', data.token);
            return data;
        } catch (error) {
            handleApiError(error);
        }
    },

    // Vet location APIs
    async searchVets(location) {
        try {
            const response = await fetch(`${API_ENDPOINTS.VETS}?location=${encodeURIComponent(location)}`, {
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                }
            });

            if (!response.ok) {
                throw new Error('Failed to fetch vet locations');
            }

            return await response.json();
        } catch (error) {
            handleApiError(error);
        }
    }
};

export default ApiService; 