
function login() {
  const popup = document.getElementById("loginPopup");
  const chat = document.getElementById("chatContainer");
  popup.style.display = "none";
  chat.style.display = "block";
}

function sendMessage() {
  const input = document.getElementById("userInput");
  const chatBox = document.getElementById("chatBox");
  const userMessage = input.value.trim();

  if (userMessage === "") return;

  const userDiv = document.createElement("div");
  userDiv.className = "message-box user-message";
  userDiv.innerText = userMessage;
  chatBox.appendChild(userDiv);
  const botDiv = document.createElement("div");
  botDiv.className = "message-box bot-message";
  botDiv.innerText = "Thanks for your message. I will help you diagnose your dog's problem.";
  chatBox.appendChild(botDiv);

  input.value = "";
  chatBox.scrollTop = chatBox.scrollHeight;
}

const chatForm = document.getElementById('chat-form');
const userInput = document.getElementById('user-input');
const chatWindow = document.getElementById('chat-window');

chatForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const message = userInput.value.trim();
    if (!message) return;
    appendMessage('user', message);
    userInput.value = '';
    const reply = getBotResponse(message);
    appendMessage('bot', reply);
});

function appendMessage(sender, text) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', sender);
    messageDiv.textContent = text;
    chatWindow.appendChild(messageDiv);
    chatWindow.scrollTop = chatWindow.scrollHeight;
}

const express = require("express");
const fetch = require("node-fetch");
const cors = require("cors");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use(cors());

const GEMINI_API_KEY = AIzaSyB13sF8QhfI7FiB514UiZqLP_OLttuBQto;

app.post("/api/ask", async (req, res) => {
  const prompt = req.body.prompt;

  try {
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${GEMINI_API_KEY}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }]
      })
    });

    const data = await response.json();
    const reply = data.candidates?.[0]?.content?.parts?.[0]?.text || "No response";

    res.json({ reply });
  } catch (error) {
    console.error("Error:", error);
    res.status(500).json({ error: "Something went wrong." });
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

window.onload = function() {
  document.getElementById('loginPopup').style.display = 'block';
  document.getElementById('overlay').style.display = 'block';
};

document.getElementById('popupLoginForm').addEventListener('submit', function(e) {
  e.preventDefault();
  document.getElementById('loginPopup').style.display = 'none';
  document.getElementById('overlay').style.display = 'none';
  alert('Logged in!');
});

document.getElementById('popupRegisterForm').addEventListener('submit', function(e) {
  e.preventDefault();
  document.getElementById('registerPopup').style.display = 'none';
  document.getElementById('overlay').style.display = 'none';
  alert('Registered!');
});

document.getElementById('showRegister').addEventListener('click', function(e) {
  e.preventDefault();
  document.getElementById('loginPopup').style.display = 'none';
  document.getElementById('registerPopup').style.display = 'block';
});

document.getElementById('showLogin').addEventListener('click', function(e) {
  e.preventDefault();
  document.getElementById('registerPopup').style.display = 'none';
  document.getElementById('loginPopup').style.display = 'block';
});

const path = require('path');

// Serve index.html from the root
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});
 const res = await fetch("http://localhost:3000/api/ask", {
  // ...
});